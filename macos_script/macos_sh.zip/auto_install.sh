./random_hostname.sh
echo "123456" | sudo -S /Volumes/Install\ macOS\ Catalina/Install\ macOS\ Catalina.app/Contents/Resources/startosinstall  --agreetolicense --forcequitapps