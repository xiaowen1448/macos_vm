ioreg -n Root -d1 | grep -i "CGSSessionLoginwindow" 
