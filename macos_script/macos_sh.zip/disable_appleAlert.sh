echo "123456" | sudo -S defaults write com.apple.systempreferences AppleIDAuthAlert -bool false
