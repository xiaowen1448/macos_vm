echo "123456" | sudo -S /System/Library/Filesystems/hfs.fs/Contents/Resources/hfs.util -s disk0s2
echo ""