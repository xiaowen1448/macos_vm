caffeinate -u -t 2
echo $?
