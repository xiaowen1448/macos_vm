yes | ~/Desktop/iMessageDebug | grep -i -w Gq3489ugfi | awk '{print "Gq3489ugfi:"$2}'
yes | ~/Desktop/iMessageDebug | grep -i -w Fyp98tpgj | awk '{print "Fyp98tpgj:"$2}'
yes | ~/Desktop/iMessageDebug | grep -i -w kbjfrfpoJU | awk '{print "kbjfrfpoJU:"$2}'
yes | ~/Desktop/iMessageDebug | grep -i -w oycqAZloTNDm | awk '{print "oycqAZloTNDm:"$2}'
yes | ~/Desktop/iMessageDebug | grep -i -w abKPld1EcMni | awk '{print "abKPld1EcMni:"$2}'

