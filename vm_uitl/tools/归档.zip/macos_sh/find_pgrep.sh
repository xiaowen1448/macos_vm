pgrep -x Finder
