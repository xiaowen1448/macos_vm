echo "123456" | sudo -S  diskutil mount disk0s1
