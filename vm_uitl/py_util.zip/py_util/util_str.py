def contains_substring(string, substring):
    return string.find(substring) != -1

