





#得到母盘虚拟机目录及文件
#D:\macos_vm\NewVM\clone_vm


#创建克隆虚拟机的目录增量排序001.....0010

#指定clone虚拟机的目录和虚拟机名称 vmrun -T ws clone  D:\macos_vm\TemplateVM\macos10.12\macos10.12.vmx  D:\macos_vm\NewVM\vm001\vm001.vmx linked

#执行克隆并启动
# vmrun  start  D:\macos_vm\TemplateVM\macos10.12\macos10.12.vmx

#得到虚拟机的IP地址

#调用修改五码配置文件


#重启后完成成品虚拟机完成

#列出克隆虚拟机的debug信息





