#!/bin/sh
ps aux | grep immac | grep -v grep | awk '{print $2}' | xargs kill
sudo shutdown -h now