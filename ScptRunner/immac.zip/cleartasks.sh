#!/bin/sh
cp -f /Users/cc/run/* /Users/cc/done/
cp -f /Users/cc/run/* /Users/cc/stoptask/
rm -rf /Users/cc/run/*
cp -f /Users/cc/lrun/* /Users/cc/ldone/
cp -f /Users/cc/lrun/* /Users/cc/lstoptask/
rm -rf /Users/cc/lrun/*