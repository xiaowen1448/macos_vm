#!/bin/sh
sleep 1
open /Applications/Messages.app/
sleep 5 
open /Users/cc/Documents/immac.app/
sleep 1
