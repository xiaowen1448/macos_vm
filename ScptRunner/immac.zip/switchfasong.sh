#!/bin/sh
rm -rf /Users/cc/modesaohao
touch /Users/cc/modefasong
echo started >> /Users/cc/modefasong