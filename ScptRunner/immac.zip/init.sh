#!/bin/sh
mkdir /Users/cc/run
mkdir /Users/cc/done
mkdir /Users/cc/result 
mkdir /Users/cc/stoptask 

mkdir /Users/cc/lrun
mkdir /Users/cc/ldone
mkdir /Users/cc/lresult 
mkdir /Users/cc/lstoptask 

cp /Users/cc/Documents/showlog /Users/cc/Desktop/showlog
cp /Users/cc/Documents/stop /Users/cc/Desktop/stop
chmod a+x /Users/cc/Desktop/showlog
chmod a+x /Users/cc/Desktop/stop