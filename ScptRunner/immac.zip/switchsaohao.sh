#!/bin/sh
rm -rf /Users/cc/modefasong
touch /Users/cc/modesaohao
echo started >> /Users/cc/modesaohao